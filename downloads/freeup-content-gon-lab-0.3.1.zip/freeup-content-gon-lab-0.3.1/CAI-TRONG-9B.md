# Cài từ gói đã giải nén

Bạn đã có gói đầy đủ: bỏ qua bước tải. Đọc [INSTALL.md](INSTALL.md), dùng install-9b.cjs --prepare → công cụ openclaw của host → --finalize cho workspace agent hiện tại. Sau đó đọc SKILL đã cài và làm init → đọc Tri thức/ảnh → assess → setup; hiển thị customerMessage với câu hỏi, mẫu còn thiếu và ba thư mục tài nguyên rồi gửi menu. Cập nhật giữ dữ liệu.

Chưa có gói đầy đủ hoặc cần bản mới: đọc [hướng dẫn trực tuyến hiện tại](https://github.com/phuongnguyendhtm/freeup-content-9b-lab/blob/main/CAI-TRONG-9B.md). Không dùng web reader để tải ZIP.
